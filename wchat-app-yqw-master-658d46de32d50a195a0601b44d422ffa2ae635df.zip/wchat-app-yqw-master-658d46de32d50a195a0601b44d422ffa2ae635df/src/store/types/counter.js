export const DISPLAY_GUIDE = 'DISPLAY_GUIDE'  // 是否显示引导关注公众号弹窗

export const IS_IOS = 'IS_IOS'  // 是否是iOS设备

export const IS_ON = 'IS_ON'  // 是否显示屏蔽的内容

export const USER_OBJ = 'USER_OBJ'  // 用户信息