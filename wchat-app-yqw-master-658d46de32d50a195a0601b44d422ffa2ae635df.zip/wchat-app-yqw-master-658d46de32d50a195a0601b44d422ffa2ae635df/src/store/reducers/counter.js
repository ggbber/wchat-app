import {handleActions} from 'redux-actions'
import {DISPLAY_GUIDE, IS_IOS, IS_ON, USER_OBJ} from '../types/counter'

export default handleActions({
    [DISPLAY_GUIDE](state) {
        return {
            ...state,
            isDisplyGuide: !state.isDisplyGuide
        }
    },
    [IS_IOS](state, action) {
        return {
            ...state,
            isIos: action.payload
        }
    },
    [IS_ON](state, action) {
        return {
            ...state,
            isOn: action.payload
        }
    },
    [USER_OBJ](state, action) {
        return {
            ...state,
            userObj: action.payload
        }
    },
}, {
    isDisplyGuide: true,
    isIos: false,
    isOn: true,
    userObj: {
        type: '',
    },
})
