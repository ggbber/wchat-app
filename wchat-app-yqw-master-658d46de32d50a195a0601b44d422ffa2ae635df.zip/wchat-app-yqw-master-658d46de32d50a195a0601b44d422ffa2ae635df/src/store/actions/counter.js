import {IS_ON, IS_IOS, USER_OBJ} from '../types/counter'
import {createAction} from 'redux-actions'
import api from '../../service/api'

export const asyncIsOn = createAction(IS_ON, () => {
    return new Promise((resolve) => {
        api.shield()
        .then(function (res) {
            if(res.status == '1') { 
                resolve(true);
            } else {
                resolve(false);
            }
        })
    })
})

export const asyncIsIos = createAction(IS_IOS, () => {
    return new Promise((resolve) => {
        wx.getSystemInfo({
            success(res) {
                if (res.platform == "ios") {
                    //ios平台
                    resolve(true);
                } else if (res.platform == "android") {
                    //android平台
                    resolve(false);
                } else if (res.platform == "devtools") {
                    //开发工具
                    resolve(false);
                }
            }
        })
    })
})

export const asyncUserObj = createAction(USER_OBJ, () => {
    return new Promise((resolve) => {
        api.getPersonData()
        .then(function (userRes) {
            if(userRes) {
                let { id, type } = userRes,
                    userObj = {
                        id,
                        type,
                    };
                resolve(userObj);
            }
        })
    })
})