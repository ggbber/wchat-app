*** 日期组件使用说明：
 
**** 导入：import datePicker from '../../components/common/datePicker';
 
**** 注册：components = { datePicker: datePicker };
   
**** 引用：
 
- 1. data内定义一个变量控制日期组件显示：
    ```
        data = { isShowDatePicker: false };

    ```
 
- 2. 使用
    ```
        <datePicker   
            wx:if="{{isShowDatePicker}}"
            defaultYear="1990"
            defaultMonth="8"
            defaultDay="8"
            defaultShiCeng="丑时"
            bind:confirmEvent="confirmDateEvent"
            bind:cancelEvent="cancelDateEvent"
        ></datePicker>

    ```
        
**** 参数说明：
- 1. defaultYear，非必传，默认年份
- 2. defaultMonth，非必传，默认月份
- 3. defaultDay，非必传，默认天数
- 4. defaultShiCeng，非必传，默认年份
- 5. confirmDateEvent，必传，确认日期回调，拿到日期信息，改变isShowDatePicker，不显示日期组件
- 6. cancelDateEvent，必传，取消日期回调，改变isShowDatePicker，不显示日期组件
 