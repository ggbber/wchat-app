export function IMG_PATH(localPaht) {
    const imageCdnPath = 'cdnPath...';  // cdn资源地址
    if(_NODE_ == 'development') {
        return localPaht;
    } else {
        return imageCdnPath;  // ...
    }
}

/**
 * 空闲控制 返回函数连续调用时，空闲时间必须大于或等于 idle，action 才会执行
 * @param idle   {number}    空闲时间，单位毫秒
 * @param fn {function}   请求关联函数，实际应用需要调用的函数
 * @return {function}    返回客户调用函数
 */
export function debounce(fn, idle) {
    var last;
    return function () {
        var that = this, args = arguments;
        clearTimeout(last);
        last = setTimeout(function () {
            fn.apply(that, args);
        }, idle);
    }
}

