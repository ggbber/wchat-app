import wepy from 'wepy'
import api from '../service/api.js'
import tips from './tips';
import {  asyncUserObj } from '../store/actions/counter'

const interfaces = {
    checkLoginSession() {
        return new Promise((resolve, reject) => {
            try {
                let localToken = wepy.getStorageSync('yiQiWenToken') || '',
                    loginType = wepy.getStorageSync('loginType') || '';

                if(localToken && loginType == 'wechat') {  // 小程序登录，校验会话有效期
                    wx.checkSession({
                        // session_key 未过期，并且在本生命周期一直有效
                        success() {
                            resolve({
                                succeeded: true
                            });
                        },
                        fail() {
                            // session_key 已经失效，需要重新执行登录流程
                            wepy.setStorageSync('isLogin', false);
                            wepy.setStorageSync('yiQiWenToken', '');
                            resolve({
                                succeeded: false
                            });
                        }
                    })
                } else {
                    resolve({
                        succeeded: false
                    });
                }
            } catch (error) {
                
            }
        });
    },
    async login(phoneObj) {
        wepy.setStorageSync('isLogin', false);
        wepy.setStorageSync('yiQiWenToken', '');
        // 获得登录数据
        let loginData = {};
        try {
            loginData = await wepy.login();
        } catch (e) {
            console.log('调用登录接口wepy.login出错')
        }
        let userinfo;
        try {
            if (loginData.code) {
                // 获取后台服务器提供的用户信息
                let data = {
                    code: loginData.code,
                    data: phoneObj.encryptedData,
                    iv: phoneObj.iv,
                };
                tips.showLoading('登录中...');
                userinfo = await api.login(data);
                tips.hideLoading();
                // 后台服务器传过来的JSON数据，小程序端有时收到的是字符串，并不是JSON对象，而且字符串前面还多了几个零宽空白字符，因此先trim一下(这里用replace函数trim)
                if (typeof userinfo === 'string') {
                    userinfo = JSON.parse(userinfo.data.replace(/(^\s+)|(\s+$)/g, ''))
                }
            } else {
                console.log('登录时获取用户code失败！')
            }
        } catch (e) {
            console.log('请求获取服务端登录态失败');
        }
        // 保存服务端登录状态
        try {
            if(userinfo && userinfo.token) {
                wepy.setStorageSync('yiQiWenToken', userinfo.token);
                wepy.setStorageSync('isLogin', true);
                wepy.setStorageSync('loginType', 'wechat');
                wepy.$store.dispatch(asyncUserObj());
                
                let newUserObjRes = await this.checkNewUser();
                if(newUserObjRes.isShow) {
                    return newUserObjRes;
                } else {
                    setTimeout(() => {
                        wx.navigateBack();
                    }, 200);
                }
            } else {
                tips.warning('登录失败');
            }
        } catch (e) {
            console.log(e);
            console.log('客户端存储会话信息失败');
        }
    },

    // 检查是否是新用户
    async checkNewUser() {
        let newUserObj = {
            uid: '',
            isShow: false,
            data: {
                name: '',
                value: '',
                mininum: '',
                desc: '',
            }
        },
        data = {
            step: 2,
            _t: new Date().valueOf(),
        };
        
        let res = await api.checkNewUser(data);
        if (res && res.new_user == 1) {
            newUserObj.data = res.coupon || {};
            newUserObj.uid = res.uid;
            newUserObj.isShow = true;
        }
        return newUserObj;
    }
}
export default interfaces;