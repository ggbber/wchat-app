/**
 * 提示与加载工具类
 */
export default class Tips {
    /**
     * 弹出成功提示框
     */

    static success(title, duration = 1000) {
        wx.showToast({
            title: title, 
            icon: 'success', 
            mask: true, 
            duration: duration
        })
    }

    /**
     * 警告框
     */
    static warning(title, duration = 1000) {
        wx.showToast({
            title: title, 
            icon: 'none', 
            mask: true, 
            duration: duration
        });
    }

    /**
     * 弹出加载提示
     */
    static showLoading(title = '加载中') {
        wx.showLoading({
            title: title,
            mask: true, 
        })
    }

    /**
     * 加载完毕
     */
    static hideLoading() {
        wx.hideLoading();
    }
}