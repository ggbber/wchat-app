// 检查提问内容是否包含特殊字符
export function askContentFlag(string) {
    const ranges = [
        '\ud83c[\udf00-\udfff]',
        '\ud83d[\udc00-\ude4f]',
        '\ud83d[\ude80-\udeff]',
    ];

    new RegExp(ranges.join('|'), 'g').test(string)
}

// 检验邮箱
export function isEmail(value, errMsg){
    if (!/^[a-z\d]+(\.[a-z\d]+)*@([\da-z](-[\da-z])?)+(\.{1,2}[a-z]+)+$/.test(value)) {
        return errMsg || '请输入正确的邮箱';
    }
}