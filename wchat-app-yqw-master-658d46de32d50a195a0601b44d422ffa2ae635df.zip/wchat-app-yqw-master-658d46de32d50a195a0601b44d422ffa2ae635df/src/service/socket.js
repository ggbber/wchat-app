import wepy from 'wepy';
export default class socket {
    static socket() {
        const apiHost = {
            development: wepy.$instance.globalData.socketDevUrl,
            production: wepy.$instance.globalData.socketProUrl
        };
        let url = '/chat_room/';
        // let dev_ws_path = 'wss://sandbox-m.yiqiwen.cn/websocket/'; let pro_ws_path =
        // 'wss://m.yiqiwen.cn/websocket/';
        let ws_path = apiHost[_NODE_] + url;
        // let res = wx.connectSocket({     url: 'wss://sandbox-m.yiqiwen.cn/websocket/'
        // }) wx.onSocketOpen(function (res) {     console.log('WebSocket连接已经打开!') })
        // return res
        return ws_path
    }
}