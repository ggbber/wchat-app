/**
 * Created by linziying on 2018/5/30.
 */
import wepy from 'wepy';
export default class socket {
    static socket() {
        const apiHost = {
            development: wepy.$instance.globalData.socketDevUrl,
            production: wepy.$instance.globalData.socketProUrl
        };
        let url = '/free_chat_room/';
        // let dev_ws_path = 'wss://sandbox-m.yiqiwen.cn/free_websocket/'; let
        // pro_ws_path = 'wss://m.yiqiwen.cn/free_websocket/';
        let ws_path = apiHost[_NODE_] + url;
        // let res = wx.connectSocket({     url:
        // 'wss://sandbox-m.yiqiwen.cn/free_websocket/' }) wx.onSocketOpen(function
        // (res) {     console.log('WebSocket免费咨询连接已经打开!') }) return res
        return ws_path
    }
}
