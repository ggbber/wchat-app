import wepy from 'wepy';
import tips from '../utils/tips';

// HTTP工具类
export default class http {
    static async request(method, url, data = {}) {
        if (method == 'GET') {
            data.retimestamp = new Date().getTime();
        }
        const apiHost = {
            development: wepy.$instance.globalData.baseDevUrl,
            production: wepy.$instance.globalData.baseProUrl
        };
        let api = apiHost[_NODE_] + url,
            token = wepy.getStorageSync('yiQiWenToken'),
            channel =
                wepy.getStorageSync('channel') ||
                wepy.$instance.globalData.channel,
            platform = wepy.$instance.globalData.platform;

        // 灵风：eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC95ZGFwaS5saW5naGl0LmNvbSIsImF1ZCI6IjE1Mzk4MjkxNDIwMDAwMDA1MCIsImlhdCI6MTU0OTg1OTE0NCwiZXhwIjoxNTgxMzk1MTQ0fQ._v6Yo2XVV1m0J5EUttmhf_AJ77ZlBtSvH3lQ4cNf6tc
        let param = {
            url: api,
            method: method,
            data: data,
            header: {
                Authorization: token,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };
        param.data.channel = channel;
        param.data.platform = platform;
        const res = await wepy.request(param);
        if (this.isSuccess(res)) {
            // 针对约定的code相应处理
            let response = res.data;
            if (response.code == 1) {
                return res.data.data;
            } else if (response.code == 1010) {
                // 未登录
                wepy.setStorageSync('isLogin', false);
                wepy.setStorageSync('yiQiWenToken', '');
                let loginType = wepy.getStorageSync('loginType') || '';
                if (loginType == 'message') {
                    // 短信登录过去，重新登录
                    tips.warning('请登录账号');
                    wx.navigateTo({
                        url: '/pages/index/login'
                    });
                }
            } else if (response.code == 1009) {
                // 数据不存在，跳转到首页
                tips.warning(response.msg);
                wx.navigateTo({
                    url: '/pages/index/index'
                });
            } else if (response.code == 0 || response.code >= 10000) {
                // 上报错误
                tips.warning(response.msg);
            } else {
                tips.warning(response.msg);
            }
        } else {
            throw this.requestException(res);
        }
    }

    /**
     * 判断请求是否成功
     */
    static isSuccess(res) {
        const wxCode = res.statusCode;
        // 微信请求错误
        if (wxCode !== 200) {
            return false;
        }
        return true;
    }

    /**
     * 异常
     */
    static requestException(res) {
        const error = {};
        error.statusCode = res.statusCode;
        const wxData = res.data,
            serverData = wxData.data;
        if (serverData) {
            error.serverCode = wxData.code;
            error.message = serverData.message;
            error.serverData = serverData;
        }
        return error;
    }

    static get(url, data) {
        return this.request('GET', url, data);
    }

    static put(url, data) {
        return this.request('PUT', url, data);
    }

    static post(url, data) {
        return this.request('POST', url, data);
    }

    static patch(url, data) {
        return this.request('PATCH', url, data);
    }

    static delete(url, data) {
        return this.request('DELETE', url, data);
    }
}
