/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-20 16:45:13
 * @LastEditTime: 2019-08-29 11:25:08
 * @LastEditors: Please set LastEditors
 */
import base from './base';

export default class api extends base { 
    // 小程序审核屏蔽
    static shield() {
        const url = `/api/comm/on_off`;
        return this.get(url);
    }
    // 登录
    static login(data) {
        const url = `/api/login/mini_program`;
        return this.post(url, data);
    }
    // 检查是否是新用户
    static checkNewUser(data) {
        const url = `/api/comm/pop_boot`;
        return this.get(url, data);
    }
    // 付费咨询室列表
    static getChatList(data) {
        const url = `/api/ask/consultant/list`;
        return this.get(url, data);
    }
    // 付费咨询室列表删除接口
    static askdel(data) {
        const url = `/api/user/askdel`;
        return this.post(url, data);
    }
    // 用户评论接口
    static addEvaluate(data) {
        const url = `/api/evaluate/add`;
        return this.post(url, data);
    }
    // 服务内容评价
    static consultantEvaluate(data) {
        const url = `/api/evaluate/consultant`;
        return this.post(url, data);
    }
    //咨询室评价相关
    static getConsultantStatus(data){
        const url = `/api/ask/consultant/status`;
        return this.get(url, data);
    }
    //打赏获取老师信息
    static rewardGetAnswerInfo(data){
        const url = `/api/teacher/info`;
        return this.get(url, data);
    }
    static rewardOrder(data){
        const url = `/api/order/reward`;
        return this.post(url, data);
    }
    //免费咨询室列表
    static myMessages(data){
        const url = `/api/message/free_chat/list`;
        return this.get(url,data);
    }
    //删除免费咨询室列表
    static delMessages(data){
        const url = `/api/message/free_msg/del`;
        return this.post(url,data);
    }
    // 首页-banner
    static getBanner() {
        const url = `/api/comm/banner`;
        return this.get(url);
    }
    // 首页-高级服务
    static getHignService(data) {
        const url = `/api/high_service/category`;
        return this.get(url, data);
    }
    // 首页-推荐服务
    static getHomeRec() {
        const url = `/api/comm/home_recommend`;
        return this.get(url);
    }
    // 首页-老师回答列表
    static getAskList(data) {
        const url = `/api/ask/list`;
        return this.get(url, data);
    }
    // 老师提问列表
    static getTeacherList(data) {
        const url = `/api/usercate/teacher`;
        return this.get(url, data);
    }
    // 快速提问列表
    static getQuickList() {
        const url = `/api/comm/quick`;
        return this.get(url);
    }
    // 快速提问-下单
    static quickOrder(data) {
        const url = `/api/order/quick`;
        return this.post(url, data);
    }
    // 获取用户信息列表
    static getUserPublicMsg() {
        const url = `/api/user/public_msg`;
        return this.get(url);
    }
    // 删除用户信息
    static delelteUserPublicMsg(data) {
        const url = `/api/user/del_public_msg`;
        return this.post(url, data);
    }
    // 添加用户信息
    static addUserMessage(data) {
        const url = `/api/user/add_public_msg`;
        return this.post(url, data);
    }
    // 获取用户面额最大的优惠券
    static getMaxCoupon(data) {
        const url = `/api/coupon/max_coupon`;
        return this.get(url, data);
    }
    // 高级服务老师列表
    static hignServiceList(data) {
        const url = `/api/high_service/teacher`;
        return this.get(url, data);
    }
    // 老师主页-获取老师介绍信息
    static getTeacherInfo(data) {
        const url = `/api/teacher/info`;
        return this.get(url, data);
    }
    // 老师主页-关注or取关老师
    static teacherFollow(data) {
        const url = `/api/teacher/follow`;
        return this.post(url, data);
    }
    // 老师主页-图片上传组件-删除图片
    static delPhoto(data) {
        const url = `/api/ask/del/image`;
        return this.post(url, data);
    }
    // 老师主页-老师评价标签
    static teacherCommentTags(data) {
        const url = `/api/teacher/evaluate_tag`;
        return this.get(url, data);
    }
    // 老师主页-老师评价列表
    static teacherCommentList(data) {
        const url = `/api/teacher/evaluate_list`;
        return this.get(url, data);
    }
    // 老师主页-老师已回答列表
    static teacherAnswerList(data) {
        const url = `/api/teacher/answered_list`;
        return this.get(url, data);
    }
    // 老师主页-高级服务项目
    static teacherHighList(data) {
        const url = `/api/teacher/serve`;
        return this.get(url, data);
    }
    // 老师普通问题下单
    static teacherCommonOrder(data) {
        const url = `/api/order/ask`;
        return this.post(url, data);
    }
    // 老师高级服务下单
    static teacherHighServiceOrder(data) {
        const url = `/api/order/consultant`;
        return this.post(url, data);
    }
    // 获取用户数据-id，type
    static getPersonData() {
        const url = `/api/user/info`;
        return this.get(url);
    }
    // 用户投诉
    static userComplain(data) {
        const url = `/api/sc/feedback`;
        return this.post(url, data);
    }
    // 偷听-获取问题
    static getPublicAsk(data) {
        const url = `/api/ask/public_info`;
        return this.get(url, data);
    }
    // 偷听-值得一听
    static getRandAsk(data) {
        const url = `/api/ask/rand_ask`;
        return this.get(url, data);
    }
    // 偷听-获取用户是否已经支付过该偷听问题
    static isTouTing(data) {
        const url = `/api/order/touting`;
        return this.post(url, data);
    }
    // 闪测-首页
    static getScHome(data) {
        const url = `/api/sc/home`;
        return this.get(url, data);
    }
    // 闪测-最热闪测数据
    static scHotList(data) {
        const url = `/api/sc/recommend`;
        return this.get(url, data);
    }
    // 闪测-根据ID获取闪测数据
    static getScDetail(data) {
        const url = `/api/sc/detail`;
        return this.get(url, data);
    }
    // 闪测-评论分页
    static scCommentList(data) {
        const url = `/api/sc/comments`;
        return this.get(url, data);
    }
    // 闪测-反馈
    static scFeedback(data) {
        const url = `/api/sc/feedback`;
        return this.post(url, data);
    }
    // 闪测-下单
    static scOrder(data) {
        const url = `/api/sc/order`;
        return this.post(url, data);
    }
    // 闪测-类别
    static scType() {
        const url = `/api/sc/cate`;
        return this.get(url);
    }
    // 闪测-按类别分类数据
    static scTypeData(data) {
        const url = `/api/sc/list`;
        return this.get(url, data);
    }
    // 个人中心-获取用户信息
    static getPerson() {
        const url = `/api/user/info`;
        return this.get(url);
    }
    // 我的问题-列表
    static getUserAsk(data) {
        const url = `/api/user/asks`;
        return this.get(url, data);
    }
    // 我的问题-删除问题
    static delAsk(data) {
        const url = `/api/user/askdel`;
        return this.post(url, data);
    }
    // 我的问题-普通问题是否公开
    static questionSetPublic(data) {
        const url = `/api/ask/set_public`;
        return this.post(url, data);
    }
    // 我的问题-问题催单
    static questionReminders(data) {
        const url = `/api/aftersale/reminders`;
        return this.post(url, data);
    }
    // 我的问题-获取出生信息
    static getUserPublicMsgById(data) {
        const url = `/api/user/one_public_msg`;
        return this.get(url, data);
    }
    // 我的问题-修改出生信息
    static editUserPublicMsgById(data) {
        const url = `/api/user/edit_public_msg`;
        return this.post(url, data);
    }
    // 我的问题-获取问题详情
    static getAskDetail(data) {
        const url = `/api/ask/info`;
        return this.get(url, data);
    }
    // 我的问题-问题打赏金额
    static getUserAskReward(data) {
        const url = `/api/ask/reward_money`;
        return this.get(url, data);
    }
    // 我的问题-问题详情页，推荐老师
    static recommendTeacher(data) {
        const url = `/api/teacher/recommend`;
        return this.get(url, data);
    }
    // 我的问题-问题评价状态
    static getEvaluateStatus(data) {
        const url = `/api/evaluate/status`;
        return this.get(url, data);
    }
    // 我的问题-追问
    static askPress(data) {
        const url = `/api/ask/press`;
        return this.post(url, data);
    }
    // 个人中心-我的关注
    static myFollow(data) {
        const url = `/api/user/follow`;
        return this.get(url, data);
    }
    // 个人中心-我的偷听
    static myListen(data) {
        const url = `/api/ask/touting`;
        return this.get(url, data);
    }
    // 个人中心-我的优惠券(未过期)
    static myValidCoupon(data) {
        const url = `/api/coupon/usable`;
        return this.get(url, data);
    }
    // 个人中心-我的优惠券(已过期)
    static myExpireCoupon(data) {
        const url = `/api/coupon/expired`;
        return this.get(url, data);
    }
    // 帮助中心-常见问题列表
    static helpQuestionList() {
        const url = `/api/helpcenter/problem/list`;
        return this.get(url);
    }
    // 帮助中心-获取业务规则
    static getRule(data) {
        const url = `/api/helpcenter/guide`;
        return this.get(url, data);
    }
    // 帮助中心-意见反馈
    static helpFeedback(data) {
        const url = `/api/comm/feedback`;
        return this.post(url, data);
    }
    // 帮助中心-查看全部问题列表
    static helpAllQuestion() {
        const url = `/api/helpcenter/problem/list`;
        return this.get(url);
    }
    // 帮助中心-查看问题详情
    static helpQuestionDetail(data) {
        const url = `/api/helpcenter/problem`;
        return this.get(url, data);
    }
    // 首页顶部搜索-热门搜索
    static hotSearch() {
        const url = `/api/search/hot_keyword`;
        return this.get(url);
    }
    // 首页顶部搜索-按关键字搜索
    static searchKeyword(data) {
        const url = `/api/search/index`;
        return this.get(url, data);
    }
    // 首页顶部搜索-搜索老师列表
    static searchTeacher(data) {
        const url = `/api/search/result`;
        return this.get(url, data);
    }
    // 精选测算-大师免费咨询列表
    static freeChatList(data) {
        const url = `/api/dszx/freechat/list`;
        return this.get(url, data);
    }
    // 精选测算-获取免费咨询室的roomId以及fromUid
    //老师主页-获取免费咨询室的roomId以及fromUid
    static getRoomId(data) {
        const url = `/api/free_chat/create_room`;
        return this.post(url, data);
    }
    // 获取未读信息数量
    static getNoticeNums() {
        const url = `/api/comm/notice`;
        return this.get(url);
    }
    // 短信验证码的加密key
    static loginPublicKey() {
        const url = `/api/comm/setting`;
        return this.get(url);
    }
    // 短信验证码的加密key
    static loginSmsCode(data) {
        const url = `/api/login/sms_code`;
        return this.post(url, data);
    }
    // 手机号登录
    static loginMobile(data) {
        const url = `/api/login/mobile`;
        return this.post(url, data);
    }
    // 个人中心-问题收益数据
    static incomeData() {
        const url = `/api/touting/info`;
        return this.get(url);
    }
    // 个人中心-问题收益我的问题列表
    static incomeQuestionList() {
        const url = `/api/touting/ask_list`;
        return this.get(url);
    }
    // 个人中心-问题收益金钱
    static withdrawMoneyMessage() {
        const url = `/api/account/withdraw_info`;
        return this.post(url);
    }
    // 个人中心-问题收益记录列表
    static incomeList(data) {
        const url = `/api/account/account_list`;
        return this.post(url, data);
    }
    // 个人中心-问题收益提现
    static withdrawMoney() {
        const url = `/api/account/withdraw`;
        return this.post(url);
    }
    //打赏成功
    static rewardSuccess(data) {
        const url = `/api/reward/success`;
        return this.get(url, data);
    }
    //获取open_id
    static getOpenid(data){
        const url = `/api/wechat/oauth`;
        return this.get(url,data);
    }
    //课程首页
    static indexClass(data){
        const url = `/api/course/home`;
        return this.get(url,data);
    }
    //课程详情页
    static courseList(data){
        const url = `/api/course/course_list`;
        return this.get(url,data);
    }
    //单个课程详情页
    static courseDetail(data){
        const url = `/api/course/course_detail`;
        return this.get(url,data);
    }
    //已购买课程列表
    static myCourseList(data){
        const url = `/api/user/course`;
        return this.post(url,data);
    }
    //单个课程详情
    static courseDetail(data){
        const url = `/api/course/course_detail`;
        return this.get(url,data);
    }
    //课程下单
    static courseOrder(data){
        const url = `/api/order/course`;
        return this.post(url,data);
    }
    //免费课程下单
    static courseFree(data){
        const url = `/api/order/course_free`;
        return this.post(url,data);
    }
    // 获取老师服务
    static highPriceService(data){
        const url = `/api/teacher/service`;
        return this.get(url,data);
    }
    //高级服务获取优惠券
    static highServiceCoupon(data){
        const url = `/api/high_service/coupon`;
        return this.get(url,data);
    }
}