import wepy from 'wepy';
import api from './api';
export default class login {
    static getLogin() {
        return new Promise((resolve, reject) => {
            wx.login({
                success(res) {
                    if (res.code) {
                        let data = {
                            code: res.code,
                            platform: 14
                        };
                        api.getOpenid(data).then((res) => {
                            resolve(res);
                        });
                    } else {
                        console.log('登录失败！' + res.errMsg)
                    }
                },
                fail(res) {
                    console.log(res)
                }
            })
        });
    }
}