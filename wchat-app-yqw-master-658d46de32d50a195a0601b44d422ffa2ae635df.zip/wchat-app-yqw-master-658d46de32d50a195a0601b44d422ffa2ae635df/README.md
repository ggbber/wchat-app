# 易起问 - 新版小程序- 前端代码(使用小程序框架wepy开发)

### 1. 运行
> 先 npm i 安装项目依赖

###  npm run dev 用于开发测试环境使用的代码
###  npm run build 用于生成生产环境代码

> 用开发者工具导入dist文件夹内容开发

###  2. 小程序appid相关

> 目前代码用在两个小程序上

- appid: wx22c6155dbb34babb，推广channel(运营提供): 1499668211，平台标识platform(后端提供): 14，原始ID：gh_2f0e65ef352f
- appid: wx6f40680ac01d1586，推广channel(运营提供): 1551432377，平台标识platform(后端提供): 29，原始ID：gh_5fdc16c2d686
- appid: wx488ec4330c52ee3d，推广channel(运营提供): 1552895912，平台标识platform(后端提供): 30，原始ID：gh_0dfea26b163e

### 3. 小程序提审前注意点

> 一套代码用于两个小程序，提审需确认好appid，channel，platform

- appid，project.config.json内修改，编译后dist/project.config.json内修改
- channel，src/app.wpy内globalData修改
- platform，src/app.wpy内globalData修改


